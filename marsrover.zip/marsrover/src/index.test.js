import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import React from 'react';
import { shallow } from 'enzyme';
 
import App from './app';

Enzyme.configure({ adapter: new Adapter() });

function setup() {
  const enzymeWrapper = shallow(<App />)

  return {
    enzymeWrapper
  }
}


describe('Mars Rovers', () => {
    it('send valid max points, start position and moves 1', () => {
      const { enzymeWrapper } = setup();
      enzymeWrapper.setState({
        maxPoints: "5 5",
        startPosition:"1 2 N",
        moves: "LMLMLMLMM"
      });
      enzymeWrapper.find('button').simulate('click');
      expect(enzymeWrapper.state('output')).toBe("1 3 N");
    });

    it('send valid max points, start position and moves 2', () => {
      const { enzymeWrapper } = setup();
      enzymeWrapper.setState({
        maxPoints: "5 5",
        startPosition:"3 3 E",
        moves: "MMRMMRMRRM"
      });
      enzymeWrapper.find('button').simulate('click');
      expect(enzymeWrapper.state('output')).toBe("5 1 E");
    });

    it('send invalid max points', () => {
      const { enzymeWrapper } = setup();
      enzymeWrapper.setState({
        maxPoints: "5",
        startPosition:"3 3 E",
        moves: "MMRMMRMRRM"
      });
      enzymeWrapper.find('button').simulate('click');
      expect(enzymeWrapper.state('output')).toBe("Invalid max points");
    });

    it('send invalid start position', () => {
      const { enzymeWrapper } = setup();
      enzymeWrapper.setState({
        maxPoints: "5 5",
        startPosition:"3 3 E R",
        moves: "MMRMMRMRRM"
      });
      enzymeWrapper.find('button').simulate('click');
      expect(enzymeWrapper.state('output')).toBe("Invalid start position");
    });

    it('send invalid moves', () => {
      const { enzymeWrapper } = setup();
      enzymeWrapper.setState({
        maxPoints: "5 5",
        startPosition:"3 3 E",
        moves: "MRMAB"
      });
      enzymeWrapper.find('button').simulate('click');
      expect(enzymeWrapper.state('output')).toBe("Invalid moves, The possible letters are L, M, R.");
    });

    it('Position can not be beyond bounderies test', () => {
      const { enzymeWrapper } = setup();
      enzymeWrapper.setState({
        maxPoints: "5 5",
        startPosition:"3 3 E",
        moves: "LMLMLMLMMMMMMM"
      });
      enzymeWrapper.find('button').simulate('click');
      expect(enzymeWrapper.state('output')).toBe("Oops! Position can not be beyond bounderies (0 , 0) and (5,5)");
    });
});