import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';

export default class App extends React.Component {
    constructor(props) {
        super(props);
        this.X = 0;
        this.Y = 0;
        this.Direction = "";
        this.InvalidMove = false;

        this.state = {
            maxPoints: '',
            startPosition:'',
            moves:'',
            output: '',
            showOutput: false,
        };
    }

    execute = () => {
       this.InvalidMove = false;
       var maxPoints = this.state.maxPoints.split(' ');
       if (maxPoints.length !== 2){
           this.setState({output: "Invalid max points",
                          showOutput : true}); 
                          return;
       }
       var startPosition = this.state.startPosition.split(' ');
       if (startPosition.length !== 3){
        this.setState({output: "Invalid start position",
                       showOutput : true}); 
                       return;
       }
       
       var moves = this.state.moves.toUpperCase();
       this.X = parseInt(startPosition[0], 10);
       this.Y = parseInt(startPosition[1], 10);
       this.Direction = startPosition[2];
       this.startMoving(moves, startPosition);
       
       if (this.InvalidMove){
        this.setState({output: "Invalid moves, The possible letters are L, M, R.",
                    showOutput : true});   
       }
       else if (this.X < 0 || this.X > maxPoints[0] || this.Y < 0 || this.Y > maxPoints[1])
       {
            this.setState({output: "Oops! Position can not be beyond bounderies (0 , 0) and (" + maxPoints[0]+","+maxPoints[1]+")",
            showOutput : true});     
       }
       else{ 
            this.setState({output: this.X + " " + this.Y + " " + this.Direction,
           showOutput : true});
       }
    };

    startMoving = (moves) => {
        for (var i = 0; i < moves.length; i++) {
          switch(moves.charAt(i)) {
            case 'M':
              this.moveInSameDirection();
              break;
            case 'L':
               this.Rotate90Left();
              break;
            case 'R':
                this.Rotate90Right();
              break;
            default:
              this.InvalidMove = true;
              break;
          }
        }
    }

      moveInSameDirection = () =>{
            switch (this.Direction)
            {
                case "N":
                    this.Y = this.Y + 1
                    break;
                case "S":
                    this.Y = this.Y - 1
                    break;
                case "E":
                    this.X = this.X + 1
                    break;
                case "W":
                    this.X = this.X - 1
                    break;
                default:
                    break;
            }
        }
    
    Rotate90Left = () => {
        switch (this.Direction)
            {
                case "N":
                     this.Direction = "W";
                    break;
                case "S":
                    this.Direction = "E";
                    break;
                case "E":
                    this.Direction = "N";
                    break;
                case "W":
                    this.Direction = "S";
                    break;
                default:
                    break;
            }
    }

    Rotate90Right = () => {
        switch (this.Direction)
            {
                case "N":
                    this.Direction = "E";
                    break;
                case "S":
                    this.Direction = "W";
                    break;
                case "E":
                    this.Direction = "S";
                    break;
                case "W":
                    this.Direction = "N";
                    break;
                default:
                    break;
            }
    }

    maxPointsChange(value){
        this.setState({
            maxPoints: value,
            showOutput: false
        });
    }

    startPositionChange(value){
        this.setState({
            startPosition: value,
            showOutput: false
        });
    }

    movesChange(value){
        this.setState({
            moves: value,
            showOutput: false
        });
    }

    render() {
        return (
            <div className="container">
            <div className="row text-white">
                <div className="col-xl-5 col-lg-6 col-md-8 col-sm-10 mx-auto text-center form p-4">
                    <div className="px-2">
                        <form className="justify-content-center" autoComplete="off"> 
                            <div className="form-group">
                                <label htmlFor="maxPoints">
                                    MaxPoints (Eg; 5 5):
                                </label>
                                <input type="text"
                                       className="form-control"
                                       id="maxPoints"
                                       required
                                       value={this.state.maxPoints}
                                       onChange={e => this.maxPointsChange(e.target.value)}/>
                            </div>
                            <div className="form-group">
                                <label htmlFor="startPositions">
                                    Start Position (Eg; 1 2 N):
                                </label>
                                <input type="text"
                                       className="form-control"
                                       id="startPositions"
                                       required
                                       value={this.state.startPosition}
                                       onChange={e => this.startPositionChange(e.target.value)}
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="moves">
                                    Moves (Eg; LMLMLMLMM):
                                </label>
                                <input type="text"
                                       id="moves"
                                       className="form-control"
                                       required
                                       value={this.state.moves}
                                       onChange={e => this.movesChange(e.target.value)}
                                />
                            </div>
                            {this.state.showOutput &&
                            <label className="label label-primary"> OUTPUT: {this.state.output } </label>} <br/>
                            <button className="btn btn-primary" type="button"  onClick={this.execute}>Execute</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        )
    }
}
